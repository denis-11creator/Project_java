package contract;


public class Timer {

	private int time;
/**
 * 
 * @author      Zangue Olivarex
 * @since       2020-05-28
 * @return time
 */
	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}
	
	public void timeDecrease(){}
}

