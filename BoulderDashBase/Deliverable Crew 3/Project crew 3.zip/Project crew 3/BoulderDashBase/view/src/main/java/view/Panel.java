package view;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * @author      Mouafo Cindy 
 * @since       2020-05-23
 *
 */
public class Panel extends JPanel {

	public void painComponent(Graphics g)
	{
		
	}

	public void update()
	{
		
	}
}
